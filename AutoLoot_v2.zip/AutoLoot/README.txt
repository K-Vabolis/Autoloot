AUTO LOOT

Install once:  pip install -r requirements.txt
Run:           auto_loot.bat

AUTO LOOT (modules\loot)
  auto_loot.bat          watches every "Talisman Online" window. When the orange loot beam rises from a
                           dead mob it right-clicks the corpse, waits for the "Searching" window, then clicks
                           "Pick up all". Background, no focus stealing. Works for any mob / any drop: it
                           only looks at the beam's colour and shape.
  auto_loot.bat "| 2"     only the window whose title contains "| 2"
  auto_loot.bat "| 2" --no-pickup    open the loot window but never click Pick up all (for testing)
  Steps: beam seen on 2 checks in a row -> right-click the green selection ring under the corpse (or the
  beam's foot if no ring) -> wait up to 2 s for the "Searching" window -> not open: retry a little to the
  side (up to 5 tries), then skip that spot for 8 s -> open: click Pick up all; if the window is still open
  afterwards (bag full), click its red X.
  The "Searching" window is recognised by parts that never change -- the "Searching" title plaque, the red X
  and the "Pick up all" button, each where it should be -- never by the item inside (the item changes).
  Test without the game:  py test_templates.py loot --image templates\loot\source\searching_window.png
                          py test_templates.py loot --image templates\loot\source\beam_samples\beam_1.png
  Test live:              test_templates.bat loot    (shows what it sees and where it would right-click)
  Tuning, all in modules\loot\spec.py:
    wrong click spot      RING_CLICK_OFFSET (corpse sits beside the ring's centre), FALLBACK_DY
    beam missed           lower BEAM_MIN_VAL / BEAM_MIN_HEIGHT;  false beam (UI gold frames, fire): raise
                          them, or add the area to IGNORE_REGIONS
    window not recognised THRESHOLD, or re-cut the PNGs: py cut_loot_templates.py newshot.png
                          (rectangles in CUT_RECTS)
  Templates: templates\loot\   Screenshots they were cut from: templates\loot\source\
