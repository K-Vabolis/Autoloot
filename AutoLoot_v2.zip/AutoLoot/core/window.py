"""Finding the game window and grabbing its pixels (works while covered)."""
import ctypes

import cv2
import numpy as np
import win32gui
import win32ui
from PIL import Image

PW_RENDERFULLCONTENT = 2  # needed for GPU-rendered windows


def find_windows(title_substring):
    """Every visible window whose title contains the text (case-insensitive)."""
    match = title_substring.lower()
    found = []

    def _enum(hwnd, _):
        if win32gui.IsWindowVisible(hwnd):
            title = win32gui.GetWindowText(hwnd)
            if title and match in title.lower():
                found.append(hwnd)

    win32gui.EnumWindows(_enum, None)
    return found


def window_title(hwnd):
    """The window's title text."""
    return win32gui.GetWindowText(hwnd)


def find_window(title_substring):
    found = find_windows(title_substring)
    return found[0] if found else None


def capture_window(hwnd):
    """Window content as a BGR image (via PrintWindow, not a screen grab)."""
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    w, h = right - left, bottom - top
    if w <= 0 or h <= 0:
        return None

    hwnd_dc = win32gui.GetWindowDC(hwnd)
    mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
    save_dc = mfc_dc.CreateCompatibleDC()
    save_bitmap = win32ui.CreateBitmap()
    save_bitmap.CreateCompatibleBitmap(mfc_dc, w, h)
    save_dc.SelectObject(save_bitmap)

    ok = ctypes.windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), PW_RENDERFULLCONTENT)

    frame = None
    if ok:
        info = save_bitmap.GetInfo()
        bits = save_bitmap.GetBitmapBits(True)
        pil = Image.frombuffer("RGB", (info["bmWidth"], info["bmHeight"]),
                               bits, "raw", "BGRX", 0, 1)
        frame = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)

    win32gui.DeleteObject(save_bitmap.GetHandle())
    save_dc.DeleteDC()
    mfc_dc.DeleteDC()
    win32gui.ReleaseDC(hwnd, hwnd_dc)
    return frame


def get_client_offset(hwnd):
    """Screenshot coords -> client coords: subtract this (dx, dy)."""
    left, top, _r, _b = win32gui.GetWindowRect(hwnd)
    cx, cy = win32gui.ClientToScreen(hwnd, (0, 0))
    return cx - left, cy - top
