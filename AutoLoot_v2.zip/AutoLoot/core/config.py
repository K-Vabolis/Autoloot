"""Shared settings for every module (login, cavebot, ...)."""
import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATES_ROOT = os.path.join(ROOT_DIR, "templates")   # templates\<module>\*.png
CAPTURES_DIR = os.path.join(ROOT_DIR, "captures")      # screenshots saved by the tester
ACCOUNTS_FILE = os.path.join(ROOT_DIR, "accounts.txt")

WINDOW_TITLE = "Talisman Online"   # substring, case-insensitive
THRESHOLD = 0.85                   # default match strictness (a module can override it in its spec.py)
LOGS_DIR = os.path.join(ROOT_DIR, "logs")               # one log per account (launch_all.py)
