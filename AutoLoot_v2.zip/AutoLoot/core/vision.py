"""Template matching. Pure OpenCV -- no Windows needed, so it can also be
tested against a saved screenshot."""
import glob
import os

import cv2

from .config import TEMPLATES_ROOT, THRESHOLD


def load_template(module, name):
    path = os.path.join(TEMPLATES_ROOT, module, name)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Template not found: {path}")
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Couldn't read '{path}' as an image (bad/corrupt file?).")
    return img


def crop_top(template, fraction):
    return template[:max(1, int(template.shape[0] * fraction)), :]


def load_templates(module, spec_templates=None):
    """Returns ({name: image}, [missing names]).

    spec_templates = {name: {"top": 0.5, "optional": True}} from a module's
    spec.py. None = just load every PNG in templates\\<module>\\.
    A missing file that is not marked optional raises FileNotFoundError.
    """
    if spec_templates is None:
        folder = os.path.join(TEMPLATES_ROOT, module)
        spec_templates = {os.path.basename(p): {}
                          for p in sorted(glob.glob(os.path.join(folder, "*.png")))}
    loaded, missing = {}, []
    for name, opts in spec_templates.items():
        try:
            tpl = load_template(module, name)
        except FileNotFoundError:
            if opts.get("optional"):
                missing.append(name)
                continue
            raise
        if opts.get("top"):
            tpl = crop_top(tpl, opts["top"])
        loaded[name] = tpl
    return loaded, missing


def best_match(frame, template):
    """Always returns (x, y, confidence) of the best spot (top-left corner)."""
    th, tw = template.shape[:2]
    sh, sw = frame.shape[:2]
    if th > sh or tw > sw:
        return 0, 0, 0.0
    res = cv2.matchTemplate(frame, template, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _mnl, loc = cv2.minMaxLoc(res)
    return loc[0], loc[1], float(mx)


def find_best_match(frame, template, threshold=THRESHOLD):
    """(x, y, confidence) if good enough, else None."""
    x, y, conf = best_match(frame, template)
    return (x, y, conf) if conf >= threshold else None
