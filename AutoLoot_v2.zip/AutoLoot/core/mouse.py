"""Background clicks (PostMessage). Ported from Zenith's send_click_bg()."""
import ctypes
import time

import win32gui

from .window import get_client_offset

CLICK_HOLD = 0.06
HOVER_DELAY = 0.08

WM_MOUSEMOVE, WM_MOUSEACTIVATE, WM_SETCURSOR, HTCLIENT = 0x0200, 0x0021, 0x0020, 1
WM_LBUTTONDOWN, WM_LBUTTONUP, MK_LBUTTON = 0x0201, 0x0202, 0x0001
WM_RBUTTONDOWN, WM_RBUTTONUP, MK_RBUTTON = 0x0204, 0x0205, 0x0002


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def _make_lparam(x, y):
    return (int(y) & 0xFFFF) << 16 | (int(x) & 0xFFFF)


def _cursor_is_over_window(hwnd):
    try:
        pt = POINT(0, 0)
        if not ctypes.windll.user32.GetCursorPos(ctypes.byref(pt)):
            return False
        l, t, r, b = win32gui.GetClientRect(hwnd)
        ox, oy = win32gui.ClientToScreen(hwnd, (l, t))
        fx, fy = win32gui.ClientToScreen(hwnd, (r, b))
        return ox <= pt.x < fx and oy <= pt.y < fy
    except Exception:
        return False


def send_click_bg(hwnd, x, y, button="left", hold=CLICK_HOLD, hover=HOVER_DELAY, use_cursor=True):
    """Click at client-area (x, y) without stealing focus.

    use_cursor=False: messages only, the real mouse cursor is NEVER touched
    (by default, when your cursor happens to be over the game window it is moved there
    for the click and put back)."""
    user32 = ctypes.windll.user32
    lparam = _make_lparam(x, y)
    down, up, mk = ((WM_RBUTTONDOWN, WM_RBUTTONUP, MK_RBUTTON) if button == "right"
                    else (WM_LBUTTONDOWN, WM_LBUTTONUP, MK_LBUTTON))

    if use_cursor and _cursor_is_over_window(hwnd):
        try:
            orig = POINT(0, 0)
            user32.GetCursorPos(ctypes.byref(orig))
            ox, oy = win32gui.ClientToScreen(hwnd, (0, 0))
            user32.SetCursorPos(ox + int(x), oy + int(y))
            user32.PostMessageW(hwnd, WM_SETCURSOR, hwnd, (WM_MOUSEMOVE << 16) | HTCLIENT)
            user32.PostMessageW(hwnd, WM_MOUSEMOVE, 0, lparam)
            time.sleep(HOVER_DELAY)
            user32.PostMessageW(hwnd, WM_MOUSEACTIVATE, hwnd, (down << 16) | HTCLIENT)
            user32.PostMessageW(hwnd, down, mk, lparam)
            time.sleep(hold)
            user32.PostMessageW(hwnd, up, 0, lparam)
            time.sleep(HOVER_DELAY)
            user32.SetCursorPos(orig.x, orig.y)
            return True
        except Exception:
            return False
        finally:
            try:
                user32.ReleaseCapture()
            except Exception:
                pass

    try:
        user32.PostMessageW(hwnd, WM_SETCURSOR, hwnd, (WM_MOUSEMOVE << 16) | HTCLIENT)
        user32.PostMessageW(hwnd, WM_MOUSEMOVE, 0, lparam)
        time.sleep(hover)
        user32.PostMessageW(hwnd, WM_MOUSEACTIVATE, hwnd, (down << 16) | HTCLIENT)
        user32.PostMessageW(hwnd, down, mk, lparam)
        time.sleep(hold)
        user32.PostMessageW(hwnd, up, 0, lparam)
        return True
    except Exception:
        return False


def click_at(hwnd, x, y, button="left", **kw):
    """Click at SCREENSHOT coordinates (converted to client coords). kw: hold, hover, use_cursor."""
    off_x, off_y = get_client_offset(hwnd)
    return send_click_bg(hwnd, x - off_x, y - off_y, button=button, **kw)


def click_template_center(hwnd, match, template, **kw):
    x, y, _conf = match
    th, tw = template.shape[:2]
    return click_at(hwnd, x + tw // 2, y + th // 2, **kw)
