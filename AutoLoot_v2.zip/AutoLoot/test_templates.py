"""Template tester -- works for ANY module (login, cavebot, ...).

    py test_templates.py                 test templates\\login against the live game window
    py test_templates.py cavebot         test templates\\cavebot
    py test_templates.py login --image shot.png   test against a saved screenshot (game not needed)
    py test_templates.py --list          list the modules (folders in templates\\)
    Options: --once  --save  --window "title"  --threshold 0.8

Prints every template's confidence (best first) so you can see how close a miss
was and tune the threshold. --save stores the captured frame in captures\\ so you
can crop new templates from it.

A module = a folder templates\\<name>\\ with PNGs. Optionally modules\\<name>\\spec.py
with TEMPLATES / THRESHOLD / extra_report(frame) so the tester matches exactly the
way that module does (see modules\\login\\spec.py). Without a spec, every PNG in the
folder is tested.
"""
import argparse
import importlib
import os
import sys
import time

import cv2

from core.config import CAPTURES_DIR, TEMPLATES_ROOT, THRESHOLD, WINDOW_TITLE
from core import vision


def list_modules():
    if not os.path.isdir(TEMPLATES_ROOT):
        return []
    return sorted(d for d in os.listdir(TEMPLATES_ROOT)
                  if os.path.isdir(os.path.join(TEMPLATES_ROOT, d)))


def load_spec(module):
    try:
        return importlib.import_module(f"modules.{module}.spec")
    except ModuleNotFoundError as e:
        if e.name and (e.name == "modules" or e.name.startswith(f"modules.{module}")):
            return None
        raise


def check(frame, module, spec, threshold):
    templates, missing = vision.load_templates(module, getattr(spec, "TEMPLATES", None))
    threshold = threshold or getattr(spec, "THRESHOLD", THRESHOLD)

    rows = []
    for name, tpl in templates.items():
        x, y, conf = vision.best_match(frame, tpl)
        rows.append((conf, name, x, y))
    rows.sort(reverse=True)

    print(f"\nFrame {frame.shape[1]}x{frame.shape[0]}  |  module '{module}'  |  threshold {threshold}")
    for conf, name, x, y in rows:
        hit = conf >= threshold
        print(f"  {conf:.2f}  {'MATCH' if hit else '     '}  {name}" + (f"  at ({x},{y})" if hit else ""))
    for name in missing:
        print(f"   --    (missing optional template: {name})")

    extra = getattr(spec, "extra_report", None)
    if extra:
        for line in extra(frame):
            print(f"  {line}")

    matched = [n[:-4] for c, n, _x, _y in rows if c >= threshold]
    print("=> " + (", ".join(matched) if matched else "none"))


def main():
    ap = argparse.ArgumentParser(description="Test templates for a module.")
    ap.add_argument("module", nargs="?", default="login")
    ap.add_argument("--list", action="store_true", help="list modules and exit")
    ap.add_argument("--image", help="test against a saved screenshot instead of the game window")
    ap.add_argument("--once", action="store_true", help="check once and exit")
    ap.add_argument("--save", action="store_true", help="save each captured frame to captures\\")
    ap.add_argument("--window", default=WINDOW_TITLE, help="window title substring")
    ap.add_argument("--threshold", type=float, default=None)
    args = ap.parse_args()

    if args.list:
        print("Modules:", ", ".join(list_modules()) or "(none)")
        return 0
    if args.module not in list_modules():
        print(f"No folder templates\\{args.module}\\. Modules: {', '.join(list_modules()) or '(none)'}")
        return 1

    spec = load_spec(args.module)

    if args.image:
        frame = cv2.imread(args.image, cv2.IMREAD_COLOR)
        if frame is None:
            print(f"Couldn't read image: {args.image}")
            return 1
        check(frame, args.module, spec, args.threshold)
        return 0

    from core.window import capture_window, find_window   # Windows only
    while True:
        hwnd = find_window(args.window)
        if not hwnd:
            print(f"No visible window found matching '{args.window}'.")
        else:
            frame = capture_window(hwnd)
            if frame is None:
                print("Couldn't capture the window (minimized? try windowed/borderless mode).")
            else:
                check(frame, args.module, spec, args.threshold)
                if args.save:
                    os.makedirs(CAPTURES_DIR, exist_ok=True)
                    path = os.path.join(CAPTURES_DIR, time.strftime("%Y%m%d_%H%M%S.png"))
                    cv2.imwrite(path, frame)
                    print(f"Saved {path}")
        if args.once:
            return 0
        if input("\nEnter = check again, q = quit: ").strip().lower().startswith("q"):
            return 0


if __name__ == "__main__":
    sys.exit(main())
