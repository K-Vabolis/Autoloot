@echo off
cd /d "%~dp0"

rem Shortcut:  auto_loot.bat "| 2"             (only the window whose title contains "| 2")
rem            auto_loot.bat "| 2" --no-pickup   (opens the loot window but never clicks Pick up all)
if not "%~1"=="" (
    py -m modules.loot.watch --window "%~1" %2 %3
    goto end
)
py -m modules.loot.watch

:end
echo.
pause
