@echo off
cd /d "%~dp0"

rem Shortcut:  test_templates.bat loot
if not "%~1"=="" (
    py test_templates.py %*
    goto end
)

py test_templates.py --list
echo.
set "MOD="
set /p MOD=Module (blank = login): 
if "%MOD%"=="" set "MOD=login"
py test_templates.py %MOD% --save

:end
echo.
pause
