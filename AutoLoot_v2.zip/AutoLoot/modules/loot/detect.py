"""Finding the loot beam and the "Searching" window in a captured frame (pure OpenCV, so it can
be tested on a saved screenshot without the game or Windows)."""
import cv2
import numpy as np

from core.vision import find_best_match
from . import spec


# ---------------------------------------------------------------- the "Searching" window
def find_loot_window(frame, templates):
    """The open "Searching" window: {"x": (cx, cy), "button": (cx, cy), "conf": c} or None.
    Needs the title plaque, the red X (fixed offset from the title) and the Pick up all
    button (same column as the title, below it) all in place."""
    title = find_best_match(frame, templates["loot_title.png"], spec.THRESHOLD)
    xbtn = find_best_match(frame, templates["loot_x.png"], spec.THRESHOLD)
    pick = find_best_match(frame, templates["loot_pickup.png"], spec.THRESHOLD)
    if not (title and xbtn and pick):
        return None
    if abs(xbtn[0] - title[0] - spec.X_OFFSET[0]) > spec.X_TOLERANCE \
            or abs(xbtn[1] - title[1] - spec.X_OFFSET[1]) > spec.X_TOLERANCE:
        return None
    dy = pick[1] - title[1]
    if abs(pick[0] - title[0] - spec.BUTTON_DX) > spec.BUTTON_TOLERANCE \
            or not spec.BUTTON_MIN_DY <= dy <= spec.BUTTON_MAX_DY:
        return None
    xh, xw = templates["loot_x.png"].shape[:2]
    ph, pw = templates["loot_pickup.png"].shape[:2]
    return {"x": (xbtn[0] + xw // 2, xbtn[1] + xh // 2),
            "button": (pick[0] + pw // 2, pick[1] + ph // 2),
            "conf": min(title[2], xbtn[2], pick[2])}


# ---------------------------------------------------------------- the beam
def _ignored(frame_shape, x, y, w, h):
    fh, fw = frame_shape[:2]
    cx, cy = x + w / 2, y + h / 2
    return any(x0 * fw <= cx <= x1 * fw and y0 * fh <= cy <= y1 * fh
               for x0, y0, x1, y1 in spec.IGNORE_REGIONS)


def find_beams(frame, loose=False):
    """Every loot beam: [{"x": cx, "bottom": y, "top": y, "height": h, "w": w, "left": x}], tallest first.

    A beam that a mob or a name tag covers part of shows up as several short orange pieces in a
    column. Pieces that line up (same column, small vertical gap) are joined into one beam, so a
    half-hidden beam is still found. Several beams side by side are reported separately."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lo = (spec.BEAM_HUE[0], spec.BEAM_MIN_SAT, spec.BEAM_MIN_VAL)
    hi = (spec.BEAM_HUE[1], 255, 255)
    mask = cv2.inRange(hsv, lo, hi)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_RECT, spec.BEAM_CLOSE))
    n, labels, stats, _c = cv2.connectedComponentsWithStats(mask, connectivity=8)

    # 1. thin, upright pieces (a whole beam or a visible part of one)
    frags = []
    for i in range(1, n):
        x, y, w, h, _a = stats[i]
        if h < spec.FRAG_MIN_HEIGHT or _a < 30:
            continue
        # tilted beams have a wide bounding box, so judge the real (rotated) shape instead
        pts = cv2.findNonZero((labels[y:y + h, x:x + w] == i).astype(np.uint8))
        (_rx, _ry), (rw, rh), _ang = cv2.minAreaRect(pts)
        thick, length = min(rw, rh), max(rw, rh)
        if thick > spec.BEAM_MAX_WIDTH or length < spec.FRAG_MIN_ASPECT * thick:
            continue
        if _ignored(frame.shape, x, y, w, h):
            continue
        foot = labels[y + int(h * 0.65): y + h, x: x + w] == i      # lower third = the piece's foot
        xs = np.nonzero(foot)[1]
        cx = x + (xs.mean() if len(xs) else w / 2)
        frags.append({"x": cx, "left": int(x), "top": int(y), "bottom": int(y + h), "w": int(w), "h": int(h),
                      "t": float(thick), "len": float(length)})

    # 2. join pieces in the same column (x within FRAG_DX, vertical gap up to FRAG_GAP)
    frags.sort(key=lambda f: f["bottom"], reverse=True)
    groups = []
    for f in frags:
        for g in groups:
            if any(abs(f["x"] - m["x"]) <= spec.FRAG_DX and
                   max(f["top"] - m["bottom"], m["top"] - f["bottom"]) <= spec.FRAG_GAP for m in g):
                g.append(f)
                break
        else:
            groups.append([f])

    beams = []
    for g in groups:
        top, bottom = min(m["top"] for m in g), max(m["bottom"] for m in g)
        left = min(m["left"] for m in g)
        w = max(m["w"] for m in g)
        t = max(m["t"] for m in g)                   # real thickness (not the tilted bounding box)
        h = bottom - top
        covered = sum(m["h"] for m in g)             # orange actually seen (the rest is hidden)
        if loose:
            ok = h >= 22
        else:
            ok = (h >= spec.BEAM_MIN_HEIGHT and covered >= spec.BEAM_MIN_VISIBLE
                  and h >= spec.BEAM_MIN_ASPECT * t)
        if not ok:
            continue
        foot = max(g, key=lambda m: m["bottom"])
        beams.append({"x": int(foot["x"]), "bottom": int(bottom), "top": int(top), "height": int(h),
                      "w": int(w), "left": int(left)})
    beams.sort(key=lambda b: -b["height"])
    return beams


def find_ring(frame, beam):
    """Centre (x, y) of the green selection ring near this beam's foot, or None."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (spec.RING_HUE[0], spec.RING_MIN_SAT, spec.RING_MIN_VAL),
                       (spec.RING_HUE[1], 255, 255))
    n, _l, stats, _c = cv2.connectedComponentsWithStats(mask, connectivity=8)
    best = None
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < spec.RING_MIN_AREA:
            continue
        cx, cy = x + w // 2, y + h // 2
        dx, dy = cx - beam["x"], cy - beam["bottom"]
        if abs(dx) > spec.RING_MAX_DX or not spec.RING_MIN_DY <= dy <= spec.RING_MAX_DY:
            continue
        if best is None or abs(dx) < best[0]:
            best = (abs(dx), cx, cy)
    return (best[1], best[2]) if best else None


def click_target(frame, beam, attempt=0):
    """(x, y, how): where to right-click for this beam. `attempt` picks a retry offset."""
    ox, oy = spec.RETRY_OFFSETS[attempt % len(spec.RETRY_OFFSETS)]
    ring = find_ring(frame, beam)
    if ring:
        x, y = ring[0] + spec.RING_CLICK_OFFSET[0], ring[1] + spec.RING_CLICK_OFFSET[1]
        how = "ring"
    else:
        x, y = beam["x"], beam["bottom"] + spec.FALLBACK_DY
        how = "beam foot"
    fh, fw = frame.shape[:2]
    return min(max(x + ox, 0), fw - 1), min(max(y + oy, 0), fh - 1), how


def report_lines(frame, templates):
    """Lines for test_templates.py: what the loot module sees in this frame."""
    lines = []
    win = find_loot_window(frame, templates)
    lines.append(f"'Searching' window: found, Pick up all at {win['button']}, X at {win['x']} ({win['conf']:.2f})"
                 if win else "'Searching' window: not found")
    beams = find_beams(frame)
    if not beams:
        lines.append("beam: not found")
    for b in beams:
        x, y, how = click_target(frame, b)
        lines.append(f"beam: x={b['x']} y={b['top']}..{b['bottom']} (height {b['height']}) "
                     f"-> would right-click ({x}, {y}) [{how}]")
    return lines
