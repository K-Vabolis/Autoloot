MODULE = "loot"
