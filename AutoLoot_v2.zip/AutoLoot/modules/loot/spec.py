"""What the loot module looks for (test_templates.py reads this too).

Two things:

 1. THE BEAM: a thin orange/gold vertical light that rises from a dead mob when it dropped
    something. We never look at the mob or the item, only at the beam's colour and shape, so
    it works for every mob and every drop.
 2. THE "SEARCHING" WINDOW: the loot window that opens after a right click. The item inside
    changes every time, so we never match it. We match the parts that don't change: the
    "Searching" title plaque, the red X, and the "Pick up all" button, and check they sit where
    they should relative to each other.
"""
THRESHOLD = 0.88

TEMPLATES = {
    "loot_title.png":  {},     # the black "Searching" plaque
    "loot_x.png":      {},     # the red X (close) button
    "loot_pickup.png": {},     # the "Pick up all" button
}

# ---- "Searching" window geometry ----
# Measured on templates\loot\source\searching_window.png (top-left of each part).
# The X sits at a fixed offset from the title plaque. The button sits in the same column as
# the title, but at any height (the window grows with the number of items).
X_OFFSET = (159, 4)
X_TOLERANCE = 4
BUTTON_DX = 2
BUTTON_TOLERANCE = 4
BUTTON_MIN_DY, BUTTON_MAX_DY = 40, 500

# Where to cut the three PNGs from templates\loot\source\searching_window.png
# (x, y, width, height). Used by cut_loot_templates.py.
CUT_RECTS = {
    "loot_title.png":  (104, 23, 84, 19),
    "loot_x.png":      (263, 27, 14, 14),
    "loot_pickup.png": (106, 196, 80, 20),
}

# ---- the beam (HSV, OpenCV scale: hue 0..179) ----
BEAM_HUE = (14, 26)           # orange / gold
BEAM_MIN_SAT = 170
BEAM_MIN_VAL = 110            # the glow is dim, the core is bright
BEAM_CLOSE = (5, 9)           # joins the beam's dashes: (width, height) of the closing kernel
BEAM_MIN_HEIGHT = 40          # px; shorter orange things (sparks, fire) are ignored
BEAM_MAX_WIDTH = 18           # px; real thickness (rotated shape) above this is ignored (health bars, UI)
BEAM_MIN_ASPECT = 4.0         # height / width must be at least this: it is a tall thin shape
# Parts of the window to ignore, as fractions (x0, y0, x1, y1) of the frame. Gold UI borders
# can look like a beam; put your toolbar / chat / minimap here if one ever triggers by mistake.
# A beam hidden in part by a mob / name tag is several short pieces in one column; join them.
FRAG_MIN_HEIGHT = 12          # px; smallest orange piece considered at all
FRAG_MIN_ASPECT = 1.5         # a piece must be at least this much taller than wide
FRAG_DX = 10                  # px; pieces within this sideways distance are one column
FRAG_GAP = 40                 # px; ... and with at most this vertical gap (hidden part) between them
BEAM_MIN_VISIBLE = 30         # px; of the joined beam, at least this much must really be orange
IGNORE_REGIONS = []
DETECT_ONLY = True            # True: just report 'beam found / no beam', never click. Set False to loot.
BEAM_MIN_SECONDS = 2.0        # a streak must stay in the same spot this long to count (flashes = fight effects)
TRACK_DX, TRACK_DY = 10, 14   # px: how far a streak may drift and still be "the same one"
TRACK_GRACE = 0.9             # s: a streak may be hidden this long (a mob walks past) without restarting
CONFIRM_FRAMES = 2            # the beam must be seen on this many checks in a row

# ---- where to click ----
# The green selection ring under a targeted corpse is the best click spot. If it's near the
# beam, click it (+ RING_CLICK_OFFSET, because the body lies beside the ring's centre).
RING_HUE = (45, 75)
RING_MIN_SAT, RING_MIN_VAL = 150, 180
RING_MIN_AREA = 120
RING_MAX_DX = 80              # ring centre may be this far left/right of the beam
RING_MIN_DY, RING_MAX_DY = -30, 80   # ... and this far above/below the beam's bottom
RING_CLICK_OFFSET = (14, -4)
# No ring: click under the beam's foot, this many px below it.
FALLBACK_DY = 22
# Retry clicks (offsets from the first spot), used one per attempt if the window doesn't open.
RETRY_OFFSETS = [(0, 0), (-12, 0), (12, -8), (0, -14), (0, 10)]
# (a beam that is still there after all 5 tries is treated as a false beam, see STUCK_RADIUS)

# ---- timing ----
OPEN_WAIT = 2.0               # seconds to wait for the "Searching" window after a right click
POLL_INTERVAL = 0.4
AFTER_PICKUP_WAIT = 0.8       # after "Pick up all", wait this long, then check if it closed
SPOT_IGNORE = 8.0             # after looting (or giving up), ignore a beam at the same spot this long
SPOT_RADIUS = 45              # px: "same spot"
STATIC_MAX_TRIES = 2          # right-click tries before a streak that opens nothing is called a false beam
STUCK_RADIUS = 8              # px: a beam that failed to open anything and never moved is a false
                              # beam (static orange UI/object); ignored until it vanishes


def extra_report(frame):
    """What the loot module sees in `frame` (used by test_templates.py)."""
    from core.vision import load_templates
    from .detect import report_lines
    templates, _missing = load_templates("loot", TEMPLATES)
    return report_lines(frame, templates)
