"""Auto loot: watches the game window(s). When the orange loot beam shows over a dead mob it
right-clicks the corpse, waits for the "Searching" window, then clicks "Pick up all".
Runs in the background (no focus stealing).

    py -m modules.loot.watch                      every window titled "Talisman Online..."
    py -m modules.loot.watch --window "| 2"       only windows whose title contains this
    py -m modules.loot.watch --no-pickup          open the loot window but never click Pick up all

Steps per beam:
  1. beam seen on CONFIRM_FRAMES checks in a row
  2. right-click the green ring under the corpse (or the beam's foot if there is no ring)
  3. wait up to OPEN_WAIT s for the "Searching" window (X + title + Pick up all all in place)
     not shown -> try again a bit to the side (spec.RETRY_OFFSETS), then give up on that spot
  4. click Pick up all; if the window is still open afterwards (e.g. bag full), click its X
Ctrl+C to stop.
"""
import argparse
import os
import time

import cv2

from core.config import CAPTURES_DIR, WINDOW_TITLE
from core.mouse import click_at
from core.vision import load_templates
from core.window import capture_window, find_windows
from . import MODULE, spec
from .detect import click_target, find_beams, find_loot_window


def log(message):
    print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


def wait_for_window(hwnd, templates, timeout):
    """Polls until the "Searching" window shows (returns it) or the time is up (None)."""
    end = time.time() + timeout
    while time.time() < end:
        time.sleep(0.15)
        frame = capture_window(hwnd)
        if frame is None:
            continue
        win = find_loot_window(frame, templates)
        if win:
            return win
    return None


def pick_up(hwnd, templates, win, do_pickup):
    """Clicks Pick up all. Never touches the X (the loot window is left for you to close). True when it closed."""
    if not do_pickup:
        log(f"Window {hwnd}: 'Searching' window open ({win['conf']:.2f}) -> not clicking (--no-pickup)")
        return False
    log(f"Window {hwnd}: 'Searching' window open ({win['conf']:.2f}) -> Pick up all")
    click_at(hwnd, *win["button"])
    time.sleep(spec.AFTER_PICKUP_WAIT)
    frame = capture_window(hwnd)
    still = find_loot_window(frame, templates) if frame is not None else None
    if not still:
        log(f"Window {hwnd}: looted, window closed")
        return True
    log(f"Window {hwnd}: window still open after Pick up all (bag full / item left?) -> leaving it open")
    return False


def near(spots, x, y, now):
    """True if (x, y) is within SPOT_RADIUS of a spot that is still being ignored."""
    return any(now < until and abs(x - sx) <= spec.SPOT_RADIUS and abs(y - sy) <= spec.SPOT_RADIUS
               for sx, sy, until in spots)


def is_stuck(stuck, beam):
    """True if this beam sits where a beam already failed to open a loot window (= not a real beam)."""
    return any(abs(beam["x"] - sx) <= spec.STUCK_RADIUS and abs(beam["bottom"] - sb) <= spec.STUCK_RADIUS
               for sx, sb in stuck)


def save_debug(frame, beam, hwnd):
    """Saves the frame with the detected beam boxed in red, so you can see what it matched."""
    try:
        os.makedirs(CAPTURES_DIR, exist_ok=True)
        img = frame.copy()
        cv2.rectangle(img, (beam["x"] - 15, beam["top"] - 5), (beam["x"] + 15, beam["bottom"] + 5),
                      (0, 0, 255), 2)
        path = os.path.join(CAPTURES_DIR, f"false_beam_{hwnd}_{beam['x']}_{beam['bottom']}.png")
        cv2.imwrite(path, img)
        return path
    except Exception:
        return None


def save_detect_image(frame, accepted):
    """captures\\detect_latest.png: green box = counted as a loot beam, red = orange but rejected."""
    try:
        os.makedirs(CAPTURES_DIR, exist_ok=True)
        img = frame.copy()
        acc = {(b["left"], b["top"]) for b in accepted}
        for b in find_beams(frame, loose=True):
            ok = (b["left"], b["top"]) in acc
            col = (0, 255, 0) if ok else (0, 0, 255)
            cv2.rectangle(img, (b["left"] - 2, b["top"] - 2), (b["left"] + b["w"] + 2, b["bottom"] + 2), col, 1)
            cv2.putText(img, f"{b['w']}x{b['height']}", (b["left"], max(b["top"] - 4, 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, col, 1)
        cv2.imwrite(os.path.join(CAPTURES_DIR, "detect_latest.png"), img)
        if accepted:    # also keep every detection, so a wrong one can be looked at afterwards
            folder = os.path.join(CAPTURES_DIR, "detections")
            os.makedirs(folder, exist_ok=True)
            cv2.imwrite(os.path.join(folder, time.strftime("%H-%M-%S") + ".png"), img)
    except Exception:
        pass


def update_tracks(tracks, beams, now, hwnd, frame):
    """Follows each orange streak over time. Returns the beams that have stayed put for
    BEAM_MIN_SECONDS (the real loot beams). In DETECT_ONLY mode it also logs found / gone."""
    for t in tracks:
        t["seen"] = False
    for b in beams:
        t = next((t for t in tracks if abs(t["x"] - b["x"]) <= spec.TRACK_DX
                  and abs(t["bottom"] - b["bottom"]) <= spec.TRACK_DY), None)
        if t is None:
            t = {"first": now, "said": False}
            tracks.append(t)
        t.update(x=b["x"], bottom=b["bottom"], beam=b, last=now, seen=True)
    confirmed = []
    for t in list(tracks):
        if now - t["last"] > spec.TRACK_GRACE:           # gone for good (short gaps are tolerated)
            tracks.remove(t)
            if t["said"] and spec.DETECT_ONLY:
                log(f"Window {hwnd}: beam gone (was at x={t['x']})")
            continue
        if now - t["first"] >= spec.BEAM_MIN_SECONDS:
            confirmed.append(t["beam"])
            if not t["said"]:
                t["said"] = True
                if spec.DETECT_ONLY:
                    b = t["beam"]
                    log(f"Window {hwnd}: BEAM FOUND at x={b['x']} y={b['top']}..{b['bottom']} "
                        f"(width {b['w']}, height {b['height']})")
                    save_detect_image(frame, [b])
    return sorted(confirmed, key=lambda b: -b["height"])


def run(title=WINDOW_TITLE, do_pickup=True):
    templates, _missing = load_templates(MODULE, spec.TEMPLATES)
    streak, spots, stuck, warned = {}, {}, {}, False
    tracks, window_open = {}, {}
    log(f"Watching windows matching '{title}' for the loot beam. Ctrl+C to stop.")
    if spec.DETECT_ONLY:
        log("DETECT_ONLY is on: only reporting whether a beam is found, no clicking.")
    if not do_pickup:
        log("--no-pickup: will open the loot window but not click Pick up all.")

    while True:
        hwnds = find_windows(title)
        if not hwnds and not warned:
            log(f"No visible window matching '{title}' yet ...")
            warned = True
        elif hwnds:
            warned = False

        for hwnd in hwnds:
            frame = capture_window(hwnd)
            if frame is None:
                continue
            now = time.time()
            ignored = spots.setdefault(hwnd, [])
            ignored[:] = [s for s in ignored if s[2] > now]

            # A loot window that is already open (we opened it, or you did): just take the loot.
            win = find_loot_window(frame, templates)
            if win:
                if spec.DETECT_ONLY:     # report only, never click
                    if not window_open.get(hwnd):
                        log(f"Window {hwnd}: 'Searching' window is open (not clicking, DETECT_ONLY)")
                    window_open[hwnd] = True
                    continue
                pick_up(hwnd, templates, win, do_pickup)
                streak[hwnd] = 0
                continue
            window_open[hwnd] = False

            # Only orange streaks that STAY in the same spot for BEAM_MIN_SECONDS count as loot beams;
            # fight effects / sparks flash and vanish.
            all_beams = update_tracks(tracks.setdefault(hwnd, []), find_beams(frame), now, hwnd, frame)
            if spec.DETECT_ONLY:
                continue
            # Forget "not a real beam" spots whose orange streak is gone (it was a real, transient beam).
            bad = stuck.setdefault(hwnd, [])
            bad[:] = [s for s in bad if any(abs(b["x"] - s[0]) <= spec.STUCK_RADIUS
                                            and abs(b["bottom"] - s[1]) <= spec.STUCK_RADIUS
                                            for b in all_beams)]
            beams = [b for b in all_beams
                     if not is_stuck(bad, b)
                     and not near(ignored, *click_target(frame, b)[:2], now)]
            if not beams:
                streak[hwnd] = 0
                continue
            streak[hwnd] = streak.get(hwnd, 0) + 1
            if streak[hwnd] < spec.CONFIRM_FRAMES:
                continue
            streak[hwnd] = 0

            beam = beams[0]
            opened, spot = None, None
            for attempt in range(len(spec.RETRY_OFFSETS)):
                x, y, how = click_target(frame, beam, attempt)
                spot = spot or (x, y)
                log(f"Window {hwnd}: loot beam at x={beam['x']} (height {beam['height']}) "
                    f"-> right-click ({x}, {y}) on the {how}, try {attempt + 1}")
                click_at(hwnd, x, y, button="right")
                opened = wait_for_window(hwnd, templates, spec.OPEN_WAIT)
                if opened:
                    break
                frame = capture_window(hwnd)
                if frame is None or not any(abs(b["x"] - beam["x"]) <= spec.SPOT_RADIUS
                                            for b in find_beams(frame)):
                    log(f"Window {hwnd}: beam is gone, moving on")
                    break
                if attempt + 1 >= spec.STATIC_MAX_TRIES:
                    break    # still there, never opened anything: stop clicking, judged below
            if opened:
                pick_up(hwnd, templates, opened, do_pickup)
            else:
                still_there = frame is not None and any(
                    abs(b["x"] - beam["x"]) <= spec.STUCK_RADIUS
                    and abs(b["bottom"] - beam["bottom"]) <= spec.STUCK_RADIUS for b in find_beams(frame))
                if still_there:
                    # Right-clicked it and nothing opened, and it's still there: not a loot beam.
                    stuck[hwnd].append((beam["x"], beam["bottom"]))
                    path = save_debug(frame, beam, hwnd)
                    log(f"Window {hwnd}: the orange streak at x={beam['x']} is not a loot beam (nothing opened, "
                        f"still there) -> ignoring it until it disappears."
                        + (f" Saved what it saw: {path}" if path else ""))
                else:
                    log(f"Window {hwnd}: the 'Searching' window never opened, skipping this spot for "
                        f"{spec.SPOT_IGNORE:.0f}s")
            ignored.append((spot[0], spot[1], time.time() + spec.SPOT_IGNORE))
        time.sleep(spec.POLL_INTERVAL)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Auto right-click loot beams and pick up everything.")
    ap.add_argument("--window", default=WINDOW_TITLE, help="window title substring")
    ap.add_argument("--no-pickup", action="store_true", help="open the loot window, don't click Pick up all")
    args = ap.parse_args()
    try:
        run(args.window, do_pickup=not args.no_pickup)
    except KeyboardInterrupt:
        log("Stopped.")
