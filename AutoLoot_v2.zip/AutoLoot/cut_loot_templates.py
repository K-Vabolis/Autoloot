"""Cuts the loot templates from the saved "Searching" window screenshot.

    py cut_loot_templates.py                 re-cut from templates\\loot\\source\\searching_window.png
    py cut_loot_templates.py shot.png        use a new screenshot (it replaces the saved source)

The rectangles (where each part sits in that screenshot) are spec.CUT_RECTS in modules\\loot\\spec.py.
Only the window itself matters: crop the screenshot to the loot window, or send the whole
game frame -- as long as the rectangles in spec.py point at the title, the X and the button.
"""
import os
import shutil
import sys

import cv2

from core.config import TEMPLATES_ROOT
from modules.loot import MODULE, spec

OUT = os.path.join(TEMPLATES_ROOT, MODULE)
SOURCE = os.path.join(OUT, "source", "searching_window.png")


def main():
    if len(sys.argv) > 1:
        os.makedirs(os.path.dirname(SOURCE), exist_ok=True)
        if os.path.abspath(sys.argv[1]) != os.path.abspath(SOURCE):
            shutil.copyfile(sys.argv[1], SOURCE)
    img = cv2.imread(SOURCE, cv2.IMREAD_COLOR)
    if img is None:
        sys.exit(f"Can't read {SOURCE}")
    for name, (x, y, w, h) in spec.CUT_RECTS.items():
        cv2.imwrite(os.path.join(OUT, name), img[y:y + h, x:x + w])
        print(f"saved templates\\{MODULE}\\{name}  ({w}x{h} from {x},{y})")


if __name__ == "__main__":
    main()
